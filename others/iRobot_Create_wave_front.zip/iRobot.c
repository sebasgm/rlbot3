/* drive.c
 * Designed to run on Create Command Module
 *
 * The basic architecture of this program can be re-used to easily 
 * write a wide variety of Create control programs.  All sensor values
 * are polled in the background (using the serial rx interrupt) and 
 * stored in the sensors array as long as the function 
 * delayAndUpdateSensors() is called periodically.  Users can send commands
 * directly a byte at a time using byteTx() or they can use the 
 * provided functions, such as baud() and drive().
 */

/****************************************************************************
*	Significant modding to the original source code has been made.
*   Copyright (c) 2007 http://www.societyofrobots.com/
*   (please link back if you use this code!)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License version 2 as
*   published by the Free Software Foundation.
*
*   Alternatively, this software may be distributed under the terms of BSD
*   license.
*
*	September 9th, 2007
*
****************************************************************************/


// Includes
#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdlib.h>
#include "oi.h"
//AVRlib includes
#include "global.h"		// include global settings
#include "a2d.h"		// include A/D converter function library
#include "wave_front.c"


// Constants
#define RESET_SONG 0
#define START_SONG 1
#define BUMP_SONG  2
#define END_SONG   3



//define port functions; example: PORT_ON( PORTD, 6);
#define PORT_ON( port_letter, number )			port_letter |= (1<<number)
#define PORT_OFF( port_letter, number )			port_letter &= ~(1<<number)
#define PORT_ALL_ON( port_letter, number )		port_letter |= (number)
#define PORT_ALL_OFF( port_letter, number )		port_letter &= ~(number)
#define FLIP_PORT( port_letter, number )		port_letter ^= (1<<number)
#define PORT_IS_ON( port_letter, number )		( port_letter & (1<<number) )
#define PORT_IS_OFF( port_letter, number )		!( port_letter & (1<<number) )



// Global variables
volatile uint16_t timer_cnt = 0;
volatile uint8_t timer_on = 0;
volatile uint8_t sensors_flag = 0;
volatile uint8_t sensors_index = 0;
volatile uint8_t sensors_in[Sen6Size];
volatile uint8_t sensors[Sen6Size];
volatile int16_t distance = 0;
signed long int angle = 0;
volatile uint16_t update_delay = 16;//minimum of 15ms per sensor update allowed!!!
volatile uint8_t range = 0;

// Scanning Variables
unsigned int scan_thresh=0;//threshold value of Sharp IR for scanner
unsigned long int scan_angle=750;//position of scanner, in units of servo command
unsigned int tmp=255;
unsigned int object_found=0;

int old_state=1;//records current pointed direction of robot: 1 is up, 2 is right, 3 is down, and 4 is left (clockwise)
int new_state=1;//required direction of robot

// Functions
void byteTx(uint8_t value);
void delayMs(uint16_t time_ms);
void delayAndUpdateSensors(unsigned int time_ms);
void initialize(void);
void powerOnRobot(void);
void baud(uint8_t baud_code);
void drive(int16_t velocity, int16_t radius);
void drive_distance(int16_t velocity, int16_t radius, int16_t distance_togo);
void drive_angle(int16_t velocity, int16_t radius, int16_t angle_togo);
uint16_t randomAngle(void);
void defineSongs(void);

//My Functions
void rotate_CCW(signed long int angle_tmp, signed long int velocity);
void rotate_CW(signed long int angle_tmp, signed long int velocity);
void straight(signed long int distance_tmp, signed long int velocity);
void stop(void);
void scan(unsigned int scan_thresh);
void servo_scan(unsigned long int speed);
void delay_cycles(unsigned long int cycles);
void find_walls(void);



int main (void) 
{
  uint8_t leds_cnt = 99;
  uint8_t leds_on = 1;


  // Set up Create and module
  initialize();
  LEDBothOff;
  powerOnRobot();
  byteTx(CmdStart);
  baud(Baud28800);
  defineSongs();
  byteTx(CmdControl);
  byteTx(CmdFull);

  // Stop just as a precaution
  drive(0, RadStraight);

  // Play the reset song and wait while it plays
  byteTx(CmdPlay);
  byteTx(RESET_SONG);
  delayAndUpdateSensors(750);


  for(;;)
  {

    if(++leds_cnt >= 100)
    {
      leds_cnt = 0;
      leds_on = !leds_on;

      if(leds_on)
      {
        byteTx(CmdLeds);
        byteTx(LEDsBoth);
        byteTx(128);
        byteTx(255);
        LEDBothOff;
      }
      else
      {
        byteTx(CmdLeds);
        byteTx(0x00);
        byteTx(0);
        byteTx(0);
        LEDBothOn;
      }
    }

    delayAndUpdateSensors(10);

    if(UserButtonPressed)
    {
      // Play start song and wait
      byteTx(CmdPlay);
      byteTx(START_SONG);
      delayAndUpdateSensors(2500);


////////////////////Enter your code below this line////////////////////

	  //reset encoder function
      angle = 0;
	  distance = 0;

	//store robot location in map
	map[robot_x][robot_y]=robot;
	//store robot location in map
	map[goal_x][goal_y]=goal;

      // Drive around until a button or unsafe condition is detected
      while(!(UserButtonPressed)
            && (!sensors[SenCliffL])
            && (!sensors[SenCliffFL])
            && (!sensors[SenCliffFR])
            && (!sensors[SenCliffR])
            && (!sensors[SenChAvailable]) && map[robot_x][robot_y]!=goal)//program ends when robot reaches goal
      {


			//LED1Off;//closest to servo
			//LED2Off;

		find_walls();
		new_state=propagate_wavefront(robot_x,robot_y,goal_x,goal_y);

		//////////////wavefront code//////////////
		while(new_state!=old_state && new_state!=0)
			{
			//if not pointed in the right direction, rotate
			if (abs(old_state - new_state) == 2)//rotate 180 degrees
				rotate_CCW(180,250);
			else if ((signed int)(old_state - new_state) == -1 || (signed int)(old_state - new_state) == 3)//rotate 90 degrees CW
				rotate_CW(90,150);
			else if ((signed int)(old_state - new_state) == 1 || (signed int)(old_state - new_state) == -3)//rotate 90 degrees CCW
				rotate_CCW(90,150);
			
		
			//make new state the old state
			old_state=new_state;
			//recheck with new location
			find_walls();
			//find new location to go to
			new_state=propagate_wavefront(robot_x,robot_y,goal_x,goal_y);
			
			}

		//there is no solution
		if (new_state==0)
			{
			byteTx(CmdPlay);//play error song
  			byteTx(BUMP_SONG);
      		delayMs(2500);
			//reset the entire map
			clear_map();
			}

		//go to new location
		else//move if there is a solution, otherwise dont move forward
			{
			straight(cell_size,100);//distance, velocity
			
			//update new location of robot
			if (new_state==1)
				robot_x--;
			if (new_state==2)
				robot_y++;
			if (new_state==3)
				robot_x++;
			if (new_state==4)
				robot_y--;
			}

		//make new state the old state
		if(new_state!=0)
			old_state=new_state;
		//////////////////////////////////////////

		/*
		//move scanner back and forth pointlessly
		tmp=60;
		while(tmp > 0)
			{
			servo_scan(300);
			delayMs(15);
			tmp=tmp-1;
			}
		while(tmp < 60)
			{
			servo_scan(1200);
			delayMs(15);
			tmp=tmp+1;
			}
		*/

		/*
		//////////////stampy code//////////////
		scan(30);

		if (scan_angle > 840)//scanner is on the right
			drive(100, RadCW);//turn right
		else if (scan_angle < 660)//scanner is on the left
			drive(100, RadCCW);
		else//drive to object in center
			{
			if (a2dConvert8bit(1) > 55)//too close, backup
				drive(-300, RadStraight);
			else
				drive(100, RadStraight);//drive to object in center
			}
		
		//straight(100,200);  //distance and speed
		//rotate_CCW(90,200); //angle and speed
		///////////////////////////////////////
		*/


////////////////////Enter your code above this line////////////////////

        // wait a little more than one robot tick for sensors to update
        delayAndUpdateSensors(update_delay);
      }

      // Stop driving
      drive(0, RadStraight);

      // Play end song and wait
      delayAndUpdateSensors(500);
      byteTx(CmdPlay);
      byteTx(END_SONG);
      delayAndUpdateSensors(2000);

    }
  }
}




// Serial receive interrupt to store sensor values
SIGNAL(SIG_USART_RECV)
{
  uint8_t temp;


  temp = UDR0;

  if(sensors_flag)
  {
    sensors_in[sensors_index++] = temp;
    if(sensors_index >= Sen6Size)
      sensors_flag = 0;
  }
}

// Timer 1 interrupt to time delays in ms
SIGNAL(SIG_OUTPUT_COMPARE1A)
{
  if(timer_cnt)
    timer_cnt--;
  else
    timer_on = 0;
}

// Transmit a byte over the serial port
void byteTx(uint8_t value)
{
  while(!(UCSR0A & _BV(UDRE0))) ;
  UDR0 = value;
}

// Delay for the specified time in ms without updating sensor values
void delayMs(uint16_t time_ms)
{
  timer_on = 1;
  timer_cnt = time_ms;
  while(timer_on) ;
}

// Delay for the specified time in ms and update sensor values
//Create updates its sensors and replies to sensor requests at a rate of
//67 Hz, or every 15 milliseconds. Do not send sensor requests faster than this.
void delayAndUpdateSensors(uint16_t time_ms)
{
  uint8_t temp;

  timer_on = 1;
  timer_cnt = time_ms;
  while(timer_on)
  {
    if(!sensors_flag)
    {
      for(temp = 0; temp < Sen6Size; temp++)
        sensors[temp] = sensors_in[temp];

      // Update running totals of distance and angle
      distance += (int)((sensors[SenDist1] << 8) | sensors[SenDist0]);
      angle += (int)((sensors[SenAng1] << 8) | sensors[SenAng0]);

      byteTx(CmdSensors);
      byteTx(6);
      sensors_index = 0;
      sensors_flag = 1;
    }
  }
  range=a2dConvert8bit(1);
}

// Initialize the Mind Control's ATmega168 microcontroller
void initialize(void)
{
  cli();

  // Set I/O pins
  DDRB = 0x12;	//12, 10   //0b00010010 (4 must be output, 5 must be input)// user a 1 for servos
  PORTB = 0xCF; //CD, CF   //0b11001111
  DDRC = 0x00;  //configure all C ports for input
  PORTC = 0x00; //make sure pull-up resistors are turned off
  DDRD = 0xE6;  //0b11100110 (1's for input)
  PORTD = 0x7D; //0b01111101 (1's for output)

  // Set up timer 1 to generate an interrupt every 1 ms
  TCCR1A = 0x00;
  TCCR1B = (_BV(WGM12) | _BV(CS12));
  OCR1A = 71;
  TIMSK1 = _BV(OCIE1A);

  // Set up the serial port with rx interrupt
  UBRR0 = 19;
  UCSR0B = (_BV(RXCIE0) | _BV(TXEN0) | _BV(RXEN0));
  UCSR0C = (_BV(UCSZ00) | _BV(UCSZ01));


  // Set up the ADC on pin C5
  a2dInit(); // initialize analog to digital converter (ADC)
  a2dSetPrescaler(ADC_PRESCALE_DIV32); // configure ADC scaling
  a2dSetReference(ADC_REFERENCE_AVCC); // configure ADC reference voltage


  // Turn on interrupts
  sei();
}

void powerOnRobot(void)
{
  // If Create's power is off, turn it on
  if(!RobotIsOn)
  {
      while(!RobotIsOn)
      {
          RobotPwrToggleLow;
          delayMs(500);  // Delay in this state
          RobotPwrToggleHigh;  // Low to high transition to toggle power
          delayMs(100);  // Delay in this state
          RobotPwrToggleLow;
      }
      delayMs(3000);  // Delay for startup
  }
}

// Switch the baud rate on both Create and module
void baud(uint8_t baud_code)
{
  if(baud_code <= 11)
  {
    byteTx(CmdBaud);
    UCSR0A |= _BV(TXC0);
    byteTx(baud_code);
    // Wait until transmit is complete
    while(!(UCSR0A & _BV(TXC0))) ;

    cli();

    // Switch the baud rate register
    if(baud_code == Baud115200)
      UBRR0 = Ubrr115200;
    else if(baud_code == Baud57600)
      UBRR0 = Ubrr57600;
    else if(baud_code == Baud38400)
      UBRR0 = Ubrr38400;
    else if(baud_code == Baud28800)
      UBRR0 = Ubrr28800;
    else if(baud_code == Baud19200)
      UBRR0 = Ubrr19200;
    else if(baud_code == Baud14400)
      UBRR0 = Ubrr14400;
    else if(baud_code == Baud9600)
      UBRR0 = Ubrr9600;
    else if(baud_code == Baud4800)
      UBRR0 = Ubrr4800;
    else if(baud_code == Baud2400)
      UBRR0 = Ubrr2400;
    else if(baud_code == Baud1200)
      UBRR0 = Ubrr1200;
    else if(baud_code == Baud600)
      UBRR0 = Ubrr600;
    else if(baud_code == Baud300)
      UBRR0 = Ubrr300;

    sei();

    delayMs(100);
  }
}




// Send Create drive commands in terms of velocity and radius
void drive(int16_t velocity, int16_t radius)
{
  byteTx(CmdDrive);
  byteTx((uint8_t)((velocity >> 8) & 0x00FF));
  byteTx((uint8_t)(velocity & 0x00FF));
  byteTx((uint8_t)((radius >> 8) & 0x00FF));
  byteTx((uint8_t)(radius & 0x00FF));
}


/*
void drive_distance(int16_t velocity, int16_t radius, int16_t distance_togo)
{
  byteTx(CmdDrive);
  byteTx((uint8_t)((velocity >> 8) & 0x00FF));
  byteTx((uint8_t)(velocity & 0x00FF));
  byteTx((uint8_t)((radius >> 8) & 0x00FF));
  byteTx((uint8_t)(radius & 0x00FF));
  byteTx(WaitForDistance);
  byteTx((uint8_t)((distance_togo >> 8) & 0x00FF));
  byteTx((uint8_t)(distance_togo & 0x00FF));
}

void drive_angle(int16_t velocity, int16_t radius, int16_t angle_togo)
{
  byteTx(CmdDrive);
  byteTx((uint8_t)((velocity >> 8) & 0x00FF));
  byteTx((uint8_t)(velocity & 0x00FF));
  byteTx((uint8_t)((radius >> 8) & 0x00FF));
  byteTx((uint8_t)(radius & 0x00FF));
  byteTx(WaitForAngle);
  byteTx((uint8_t)((angle_togo >> 8) & 0x00FF));
  byteTx((uint8_t)(angle_togo & 0x00FF));
}
*/

/*
// Return an angle value in the range 53 to 180 (degrees)
uint16_t randomAngle(void)
{
    return (53 + ((uint16_t)(random() & 0xFF) >> 1));
}
*/


// Define songs to be played later
void defineSongs(void)
{
  // Reset song
  byteTx(CmdSong);
  byteTx(RESET_SONG);
  byteTx(4);
  byteTx(60);
  byteTx(6);
  byteTx(72);
  byteTx(6);
  byteTx(84);
  byteTx(6);
  byteTx(96);
  byteTx(6);

  // Start song
  byteTx(CmdSong);
  byteTx(START_SONG);
  byteTx(6);
  byteTx(69);
  byteTx(18);
  byteTx(72);
  byteTx(12);
  byteTx(74);
  byteTx(12);
  byteTx(72);
  byteTx(12);
  byteTx(69);
  byteTx(12);
  byteTx(77);
  byteTx(24);

  // Bump song
  byteTx(CmdSong);
  byteTx(BUMP_SONG);
  byteTx(2);
  byteTx(74);
  byteTx(12);
  byteTx(59);
  byteTx(24);

  // End song
  byteTx(CmdSong);
  byteTx(END_SONG);
  byteTx(5);
  byteTx(77);
  byteTx(18);
  byteTx(74);
  byteTx(12);
  byteTx(72);
  byteTx(12);
  byteTx(69);
  byteTx(12);
  byteTx(65);
  byteTx(24);
}



////////////SoR Functions////////////

//rotate a certain angle - 100 = 90 degrees!
void rotate_CCW(signed long int angle_tmp, signed long int velocity)
	{
	//Counter-clockwise angles are positive and clockwise angles are negative.
	drive(velocity, RadCCW);

	while(angle<angle_tmp)
		delayAndUpdateSensors(update_delay);//flaw is that if it goes above in the middle of function, it will drift

	stop();
	delayAndUpdateSensors(update_delay);

	angle=angle-angle_tmp;//resets angle to 0; accounts for an over/undershoot
	angle=0;
	}


//rotate a certain angle - 100 = 90 degrees!
void rotate_CW(signed long int angle_tmp, signed long int velocity)
	{
	//Counter-clockwise angles are positive and clockwise angles are negative.
	drive(velocity, RadCW);

	while((-angle)<angle_tmp)
		delayAndUpdateSensors(update_delay);//flaw is that if it goes above in the middle of function, it will drift

	stop();
	delayAndUpdateSensors(update_delay);

	angle=angle-angle_tmp;//resets angle to 0; accounts for an over/undershoot
	angle=0;
	}


//drive straight function (use negative velocity to go in reverse)
void straight(signed long int distance_tmp, signed long int velocity)
	{
	drive(velocity, RadStraight);

	while(distance<distance_tmp)//flaw is that if it goes above in the middle of function, it will drift
		delayAndUpdateSensors(update_delay);

	stop();
	delayAndUpdateSensors(update_delay);

	distance=distance-distance_tmp;//resets angle to 0; accounts for an over/undershoot
	}


//stop motors
void stop(void)
	{
	drive(0, RadStraight);
	delayAndUpdateSensors(update_delay);
	}


//EDGE DETECTION
//this function causes scanning servo to center on edge of object
void scan(unsigned int scan_thresh)
	{
	//lower (-) goes right
	//higher (+) goes left

	/*psuedocode
	object is detected
		scan CW while object is detected (right)
	object not detected
		scan CCW until object detected (left)*/
	
	if (a2dConvert8bit(1) > scan_thresh)//object detected range
		{
		if (scan_angle>300) //overflow protection, servo cant rotate any further (minimum CCW, 500 is good)
			scan_angle-=10; //scan left, higher number makes it go faster
		}
	else //object not detected
		{
		if (scan_angle<=1200) //maximum position scanner can rotate to (maximum CW, 900 is good)
			scan_angle+=10; //scan left
		//else //if scanned all the way, this forces it to start over
		//	scan_angle=30;
		}
		
	//servo scan code
	servo_scan(scan_angle);
	}

//UPDATE MAP BY SCANNING FOR WALLS
void find_walls(void)
	{
	//do not scan outside the border region
	if((old_state==1 && robot_x==0) || (old_state==2 && robot_y==5) || (old_state==3 && robot_x==5) || (old_state==4 && robot_y==0))
		return;
	
	else
		{
		scan_angle=660;

		//reset scanner
		servo_scan(scan_angle);
		delayMs(40);
		servo_scan(scan_angle);
		delayMs(40);
		servo_scan(scan_angle);
		delayMs(40);

		object_found=0;

		//do a full scan until something is sensed in the way
		while(scan_angle < 942 && object_found==0)
			{
			if (a2dConvert8bit(1) > scan_one_cell)//object found: add it to the map
				{
				//account for angle of the robot wrt the map, and stay in boundaries
				if (old_state==1)// && robot_x>0)
					map[robot_x-1][robot_y]=wall;
				else if (old_state==2)// && robot_y<5)
					map[robot_x][robot_y+1]=wall;
				else if (old_state==3)// && robot_x<5)
					map[robot_x+1][robot_y]=wall;
				else if (old_state==4)// && robot_y>0)
					map[robot_x][robot_y-1]=wall;
				object_found=1;
				}

			//servo scan code
			//-90 degrees at 300, lower goes CCW, 750 is centered, 1200 is far CW
			servo_scan(scan_angle);
			delayMs(12);
			scan_angle++;
			}
			
		if(object_found==0) //no object found, so clear it in the map
			{
			//account for angle of the robot wrt the map, and stay in boundaries
			if (old_state==1)// && robot_x>0)
				map[robot_x-1][robot_y]=nothing;
			else if (old_state==2)// && robot_y<5)
				map[robot_x][robot_y+1]=nothing;
			else if (old_state==3)// && robot_x<5)
				map[robot_x+1][robot_y]=nothing;
			else if (old_state==4)// && robot_y>0)
				map[robot_x][robot_y-1]=nothing;
			}
		}
	//makes sure robot/goal location isnt replaced with a wall
	//store robot location in map
	map[robot_x][robot_y]=robot;
	//store robot location in map
	map[goal_x][goal_y]=goal;
	}

//************DELAY FUNCTIONS************
//wait for X amount of cycles
//DOES NOT WORK IF OPTIMIZATION IN MAKEFILE IS TURNED ON!!!!!!!!
void delay_cycles(unsigned long int cycles)
	{
	while(cycles > 0)
		cycles--;
	}
//***************************************

//-90 degrees at 300, lower goes CCW, 750 is centered, 1200 is far CW
void servo_scan(unsigned long int speed)
	{
	PORT_ON(PORTB, 1);
	delay_cycles(speed);
	PORT_OFF(PORTB, 1);//keep off
	//delayMs(8);
	}




